"use client"

import { Todo } from "./todo.types"

type MonitorTarefasProps = {
    todos: Todo[]
}

export function MonitorTarefas(props: MonitorTarefasProps){

    const total = props.todos.length
    const concluidas = props.todos.filter((tarefa: Todo) => tarefa.completed).length
    const pendentes = total - concluidas

    return (
        <div className="flex flex-col gap-2 py-4">
            <div className="flex gap-8 text-center">
                <div className="flex flex-col">
                    <span className="text-3xl font-bold">{total}</span>
                    <span>Total</span>
                </div>
                <div className="flex flex-col">
                    <span className="text-3xl font-bold">{pendentes}</span>
                    <span>Pendentes</span>
                </div>
                <div className="flex flex-col">
                    <span className="text-3xl font-bold">{concluidas}</span>
                    <span>Concluídas</span>
                </div>
            </div>

            {total > 0 && pendentes === 0 && (
                <p className="font-bold">Todas as tarefas foram concluídas!</p>
            )}
        </div>
    )
}
